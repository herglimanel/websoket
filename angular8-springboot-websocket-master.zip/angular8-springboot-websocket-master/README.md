# angular8-springboot-websocket
angular8-springboot-websocket tutorial

https://www.javaguides.net/2019/06/spring-boot-angular-8-websocket-example-tutorial.html
